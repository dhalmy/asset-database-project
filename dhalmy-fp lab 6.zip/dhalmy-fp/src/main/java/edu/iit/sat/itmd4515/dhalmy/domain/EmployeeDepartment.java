/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.iit.sat.itmd4515.dhalmy.domain;

/**
 *
 * @author David
 */
public enum EmployeeDepartment {
    RPI, //research, policy, and implementation
    RAP, //research and planning
    FINANCE,
    COMMS, //communications
    EXECUTIVE,
    IT,
    PLANNING,
    GOVAFFAIRS, //government affairs
    HR,
    ExEmployee
    
}
