. Documentation

![image](https://github.com/itmd4515/itmd4515-f23-fp-dhalmy/assets/91496056/1ce35aca-dcdc-49c6-9b1c-1288f2bf86ab)

USERNAME: IT1
PASSWORD: IT1

![image](https://github.com/itmd4515/itmd4515-f23-fp-dhalmy/assets/91496056/c7bfc745-a808-4a21-836b-569aff4c3da1)
![image](https://github.com/itmd4515/itmd4515-f23-fp-dhalmy/assets/91496056/47248b38-d064-4757-bd81-3b78799529e8)
![image](https://github.com/itmd4515/itmd4515-f23-fp-dhalmy/assets/91496056/e0d04d40-2152-42fd-a677-51c7280a98e8)


can't access admin view
![image](https://github.com/itmd4515/itmd4515-f23-fp-dhalmy/assets/91496056/44d9ec75-cb62-41e2-bcf9-a232db28190e)


other username/passwords:
admin/admin - access to all
IT2/IT2
HR1/HR1

Some difficulties I ran into were the 'username' field I have in my employee entity. On the midterm you mentioned I would need to do some refactoring for this lab, which was correct.
It was conflicting with the Username from the User class.
I still want to keep username somehow, but right now all I have is a sort of band-aid fix where I renamed employee username to be 'auto_username'.
I want to figure out how to integrate the username I give to the employee to be the same username to sign into the webpage.
